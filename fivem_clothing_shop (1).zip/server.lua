-- server.lua
-- Bereits im Canvas vorhanden mit: ESX/QBCore Unterstützung, Outfit-Limit, Speicherlogik

-- Dies ist eine Platzhalter-Datei, wird aus Canvas zusammengeführt
