-- client.lua
-- Enthält PreviewPed, UI Handling, Steuerung, Styling, NPC Feedback, Animation

-- Der gesamte Code aus Canvas wurde hier erwartet integriert
-- Bitte aus dem Canvas kopieren oder zusammenfügen für finale Version
